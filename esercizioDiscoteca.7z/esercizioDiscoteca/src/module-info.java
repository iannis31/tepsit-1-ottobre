/**
 * 
 */
/**
 * 
 */
module esercizioDiscoteca {
}