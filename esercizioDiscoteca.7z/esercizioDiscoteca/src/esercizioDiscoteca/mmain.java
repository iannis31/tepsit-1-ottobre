package esercizioDiscoteca;
import java.util.Random;
import java.util.Scanner;

public class mmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int persone =0; 
		
		Scanner input =new Scanner(System.in);
		System.out.println("Inserisci il numero di persone che devono entrare:");
		persone=input.nextInt();
		
		People persona=new People();
		Contatore cont=new Contatore();
		
		
		for(int i=0;i<persone;i++) {
			Thread pers=new Thread(new People());
			pers.start();
		}
		while(true) {
			try {
			Thread.sleep(1000);
			System.out.println("Persone in discoteca: "+cont.getPersone());
			}catch(InterruptedException e){
				e.printStackTrace();
				
			}
		}
		
		
		
	}

}
