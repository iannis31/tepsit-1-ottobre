package esercizioDiscoteca;

import java.util.Random;

public class People {
	Contatore cont =new Contatore();
	Random random =new Random();
	
	public void run() {
		while(true) {
			try {
				cont.entra();
				Thread.sleep(random.nextInt(5000) + 2000);
				cont.esci();
				Thread.sleep(random.nextInt(5000) + 2000);
			}catch (InterruptedException e) {
                e.printStackTrace();
            }

		}
	}
}
