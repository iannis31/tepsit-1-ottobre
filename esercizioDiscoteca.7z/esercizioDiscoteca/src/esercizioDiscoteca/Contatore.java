package esercizioDiscoteca;

public class Contatore {
	private static int numeroPersone=0;

	public synchronized void entra() {
		numeroPersone++;
		System.out.println(Thread.currentThread().getName()+" enter");
	}
	public synchronized void esci() {
		numeroPersone--;
		System.out.println(Thread.currentThread().getName()+" exit");
	}
	public int getPersone() {
		return numeroPersone;
	}
}
