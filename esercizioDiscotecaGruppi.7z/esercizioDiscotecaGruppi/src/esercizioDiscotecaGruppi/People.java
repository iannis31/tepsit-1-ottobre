package esercizioDiscotecaGruppi;
import java.util.Random;

public class People implements Runnable {
	
	Random rand= new Random();
	Contatore cont=new Contatore();
	int persone;
	
	public People(int n) {
		persone = n ;
	}
	
	public void run() {
		
		try {
			cont.entra(persone);
			Thread.sleep(rand.nextInt((6000)+4000));
			cont.esce(persone);
			Thread.sleep(rand.nextInt((6000)+4000));
		}catch(InterruptedException e) {
			
		
		}
	}
}
