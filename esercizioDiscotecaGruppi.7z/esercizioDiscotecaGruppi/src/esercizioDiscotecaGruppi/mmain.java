package esercizioDiscotecaGruppi;
import java.util.Random;
import java.util.Scanner;

public class mmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int gruppi =0; 
		
		Scanner input =new Scanner(System.in);
		System.out.println("Inserisci il numero di gruppi che devono entrare:");
		gruppi=input.nextInt();
		
		Random rand=new Random();
		Contatore cont = new Contatore();
		
		for(int i=0;i<gruppi;i++) {
			int n=rand.nextInt((20)+1);
			new Thread(new People(n)).start();
			
		}
		while(true) {
			try {
				Thread.sleep(2000);
				System.out.println("Persone nella discoteca: "+cont.getPersone());
			}catch(InterruptedException e) {
				
			}
		}
	}

	}

