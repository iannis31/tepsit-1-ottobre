package esercizioA;

public class Incrementatore implements Runnable {

	private int lim;
	private Contatore c;
	

	public void setLim(int l) {
	lim=l;	
	} 
	

	public Incrementatore(Contatore c,int n) {
		this.c=c;
		this.lim=n;
	}
	
	
// nel metodo run utilizzo il metodo incrementa della classe contatore
// per incrementare n
// l'incremento lo svolgo nella classe run per far si che tutti i miei thread possono incrementare n
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		int valore = c.incrementa(lim);
		
		if(valore==-1)
		System.out.println(Thread.currentThread().getName()+" - "+valore);
		
	}
}
