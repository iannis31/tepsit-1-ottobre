package esercizioA;

public class Contatore {
	
	int count=0;

// creo un metodo che mi incrementa la variabile count 
// controllando se la variabile count è maggiore di n allora returno -1
// incrementa mi tiene traccia del numero che i miei thread devono contare 
	public int incrementa(int lim) {
			if(count<lim) {
				count++;
			return count;
			}else {
				return -1;
			}
			}
	}
