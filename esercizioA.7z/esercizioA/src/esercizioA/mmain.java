package esercizioA;
import java.util.Scanner;

/* Creare un programma che chiede due valori T ed N
 * crea T Thread che in maniera condivisa 
 * collaborativa stampano i valori da 1 ad N 
 * (quindi nessun numero da 1 ad N può essere stampato più di una volta) 
 * NOTA: Non è necessario che la stampa a video sia ordinata da 1 ad N
*/

public class mmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int t =0; 
		int n =0; 
		Contatore c=new Contatore();
		
		
		Scanner input =new Scanner(System.in);
		System.out.println("Inserisci il numero di Thread:");
		t=input.nextInt();
		System.out.println("Inserisci il limite del contatore:");
		n=input.nextInt();
		
		
		for(int i=0;i<t;i++) {
			Thread T=new Thread(new Incrementatore(c,n));
			T.start();
		}
	}
}


