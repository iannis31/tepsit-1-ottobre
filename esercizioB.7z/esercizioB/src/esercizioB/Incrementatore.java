package esercizioB;



public class Incrementatore implements Runnable  {
	private int lim;
	private Contatore c;
	
	

	public void setLim(int l) {
		lim=l;	
	} 
	

	public Incrementatore(Contatore c,int n) {
		this.c=c;
		this.lim=n;
 
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		 
		
		
		int valore = c.incrementa(lim);
		
		
		if(valore==-1)
		System.out.println(Thread.currentThread().getName()+" - "+valore);
		 
	}
	

}
