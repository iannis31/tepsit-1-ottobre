package esercizioB;
import java.util.Scanner;


public class mmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				int t =0; 
				int n =0; 
				int coppie=0; 
				Contatore c=new Contatore();
				
				
				Scanner input =new Scanner(System.in);
				System.out.println("Inserisci il numero di Thread:");
				t=input.nextInt();
				System.out.println("Inserisci il limite del contatore:");
				n=input.nextInt();
				
				if(t%2!=0) {
					t++; 
				}
				
				coppie = t/2; 
				int cp=0; 
				while(cp<coppie) {
				for(int i=0;i<t;i++) {
					Thread T=new Thread(new Incrementatore(c,n));
					T.start();
					cp++; 
				}
				}
	}

}
