/**
 * 
 */
/**
 * 
 */
module esercizioB {
}